import math
import random
# This was done on Sat May 12 14:31:53 IST 2018
# example.py

def average(l):
    s = 0
    for i in l:
        s = s + i
    return s/len(l)

def num_digits(n):
    return len(str(n))

def panagram(s):
    for letter in "abcdefghijklmnopqrstuvwxyz":
        if letter not in s:
            print ("{} is missing".format(letter))
            return False
    return True


def estimate_pi(iters):
    inside = 0
    for i in range(iters):
        x = random.uniform(0, 1)
        y = random.uniform(0, 1)
        if (x**2 + y**2) <=1:
            inside += 1
        # estimate = (4 * inside)/(i+1)
        # print ("{} - {}".format(i+1, estimate))
    return (4*inside)/iters


def word_count(fname):
    f = open(fname)
    data = f.read()
    words = len(data.split())
    f.close()
    return words

def compute_ari(fname):
    f = open(fname)
    contents = f.read()
    f.close()

    n_chars = 0
    for i in contents:
        if i.isalnum():
            n_chars = n_chars + 1
    
    n_words = contents.count(" ") + contents.count("\n")
    
    n_sentences = contents.count(".") + contents.count("!") + contents.count("?")

    ari = 4.71 * (n_chars/n_words) + 0.5 * (n_words/n_sentences) - 21.43
    ari = math.ceil(ari)


    scores = {1: ["5-6", "Kindergarten"],
              2: ["6-7", "First Grade"],
              3: ["7-8", "Second Grade"],
              4: ["8-9", "Third Grade"],
              5: ["9-10", "Fourth Grade"],
              6: ["10-11", "Fifth Grade"],
              7: ["11-12", "Sixth Grade"],
              8: ["12-13", "Seventh Grade"],
              9: ["13-14", "Eighth Grade"],
              10: ["14-15", "Ninth Grade"],
              11: ["15-16", "Tenth Grade"],
              12: ["16-17", "Eleventh grade"],
              13: ["17-18", "Twelfth grade"],
              14: ["18-22", "College"]}

    return scores[ari]


def freq(s):
    d = {}
    for i in s:
        if i in d:
            d[i] += 1
        else:
            d[i] = 1
    return d



